Simple Gas Station simulation.
Input a valid credit_card_number to gain access to gas_type and ammount
The credit_card_number validity is checked by "checkLuhn"
U ll need to go to "File file = new File" and set the .txt "path" where the actions ll be logged