Simple ATM simulation.
Input account information to then gain access to deposit/withdrawl screen, loggin those actions in a .txt
The account information -credit_card_number + password combination is in "logininfo" (add an account here to access)
U ll need to go to "File file = new File" and set the .txt "path"