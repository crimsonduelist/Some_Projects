U ll simply need to build a local db first with the scripts provided.
The app is in RestaurantApp.7z