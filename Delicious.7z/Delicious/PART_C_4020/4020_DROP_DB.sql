drop table provides;
drop table AMENITIES;
drop table Phone;
drop table KRATHSH;
drop table Pelatis;
drop table TRAPEZI;
drop table KATHGORIES;