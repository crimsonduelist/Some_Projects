create index index1 ON KRATHSH(reservationno,kid,outdate,bill,tid,pid);
create INDEX index2 on PELATIS(PID,LNAME,FNAME);
create INDEX index3 on TRAPEZI(TID,FLOOR);